package com.example.paymentgateway;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements PaymentResultListener {
    private TextView PayStatus;
    private Button payBtn;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Checkout.preload(getApplicationContext());

        PayStatus=findViewById(R.id.tv_payStatus);
        payBtn=findViewById(R.id.payBt);


        payBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PaymentNow("1");
            }
        });
    }

    private void PaymentNow(String amount) {
        final Activity activity = this;
         Checkout checkout = new Checkout();
         checkout.setKeyID("rzp_test_xorJlj13BsDgHc");
         checkout.setImage(R.drawable.ic_launcher_background);

        double finalAmount = Float.parseFloat(amount) *100;
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("name","NADEEM");
            jsonObject.put("description","Reference No. #123456");
            jsonObject.put("theme.color","#3399cc");
            jsonObject.put("amount",finalAmount+"");
            jsonObject.put("prefill.email","mn86430@gmail.com");
            jsonObject.put("prefill.contact","8795857805");
        //    jsonObject.put("image","NADEEM");

             checkout.open(activity,jsonObject);

        } catch (JSONException e) {

            Log.e("TAG","Error in starting Razorpay Checkout",e);
        }

    }

    @Override
    public void onPaymentSuccess(String s) {


        Toast.makeText(this, "Payment success!", Toast.LENGTH_SHORT).show();
        PayStatus.setText(s);
    }

    @Override
    public void onPaymentError(int i, String s) {
        Toast.makeText(this, "Payment Failed!", Toast.LENGTH_SHORT).show();
        PayStatus.setText(s);
    }

}